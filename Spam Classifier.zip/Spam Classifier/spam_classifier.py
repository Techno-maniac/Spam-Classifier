import re  # regex module in python

from nltk.tokenize import word_tokenize  # word_tokenize splits the text into tokens

from nltk import PorterStemmer  # module for stemming words

import numpy as np

from scipy.io import loadmat  # module to import mat data file in python

from sklearn import svm  # module for support vector machine

from sklearn.metrics import accuracy_score  # module for computing accuracy

from sklearn.model_selection import train_test_split  # module to split data into training and testing set

import os


def get_vocab_dict_function():
    vocab_dict = {}
    with open('vocab.txt') as f:
        for line in f:
            (val, key) = line.split()
            vocab_dict[key] = int(val)

    return vocab_dict


def process_email_function(email):

    email = email.lower()  # converting whole email to lower case

    email = re.sub(r'<.*?>', r' ', email)  # replacing html tags to white space character

    email = re.sub(r'(https?)?://www\.[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+/?', r'httpaddr', email)  # replacing all URLs to the text "httpaddr"

    email = re.sub(r'[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+', r'emailaddr', email)  # replacing all email addresses to the text "emailaddr"

    email = re.sub(r'\d+', r'number', email)  # replacing all numbers by the text "number"

    email = re.sub(r'\$+', r'dollar', email)  # replacing the dollar sign by the text "dollar"

    email = re.sub(r'[^\w]+', r' ', email)  # tripping all the punctuation, white space and new line character with the white space

    return email


def email_to_stemmed_word_function(email):
    stemmed_word_list = []
    email = process_email_function(email)
    # converting the complete email into tokens of single word
    tokens = word_tokenize(email)
    ps = PorterStemmer()
    for token in tokens:
        stemmed_word_list.append(ps.stem(token))

    return stemmed_word_list


def stemmed_to_indices_list_function(email, vocab_dict):
    indices_list = []
    stemmed_word_list = email_to_stemmed_word_function(email)
    for word in stemmed_word_list:
        if word in vocab_dict:
            indices_list.append(vocab_dict[word])

    return indices_list


def email_to_feature_vector_function(email):
    vocab_dict = get_vocab_dict_function()
    feature_vector = np.zeros((1, len(vocab_dict)))
    indices_list = stemmed_to_indices_list_function(email, vocab_dict)
    for i in indices_list:
        feature_vector[0, i-1] = 1

    return feature_vector


data_1 = loadmat('spamTrain.mat')
data_2 = loadmat('spamTest.mat')
X = np.vstack((data_1['X'], data_2['Xtest']))
y = np.vstack((data_1['y'], data_2['ytest']))

print("Percentage of spam ", (np.sum(y)/len(y))*100)
print("Percentage of non-spam: ", round(((len(y)-np.sum(y))/len(y))*100, 3))

X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8)

'''
def get__gaussian_param_function(X, y, Xtest, ytest):
    C = [0.01, 0.03, 0.1, 0.3, 1, 3, 10, 30]
    sigma = [0.01, 0.03, 0.1, 0.3, 1, 3, 10, 30]
    score = np.zeros((len(C), len(sigma)))
    for c in range(0, len(C)):
        for s in range(0, len(sigma)):
            svm_clf = svm.SVC(kernel="rbf", C=C[c], gamma=sigma[s])
            svm_clf.fit(X, y.ravel())
            score[c, s] = accuracy_score(ytest, svm_clf.predict(Xtest))
    max_C_index, max_sigma_index = np.unravel_index(score.argmax(), score.shape)

    return C[max_C_index], sigma[max_sigma_index]
'''


def get_linear_param_function(X, y, Xtest, ytest):
    C = [0.01, 0.03, 0.1, 0.3, 1, 3, 10, 30]
    score = []
    for i in range(0, len(C)):
        svm_clf = svm.SVC(kernel="linear", C=C[i])
        svm_clf.fit(X, y.ravel())
        score.append(accuracy_score(ytest, svm_clf.predict(Xtest)))
    score = np.array(score)

    return C[score.argmax()]


# initialising the value for svm regularisation parameter and sigma
C = 0.03  # get_linear_param_function(X_train, y_train, X_test, y_test)

# training the support vector machine using our training set
svm_clf = svm.SVC(kernel="linear", C=C)
svm_clf.fit(X_train, y_train.ravel())

for filename in os.listdir("sample_mails"):
    email_handle = open("sample_mails/" + filename, 'r')
    if svm_clf.predict(email_to_feature_vector_function(email_handle.read())) == 1:
        email_handle.seek(0)
        email_write = open("Spam/" + filename, 'w')
        email_write.write(email_handle.read())
        email_write.close()
    else:
        email_handle.seek(0)
        email_write = open("Non Spam/" + filename, 'w')
        email_write.write(email_handle.read())
        email_write.close()
    email_handle.close()


# accuracy score of the training and the testing set
print("Accuracy of the training set is ", round(accuracy_score(y_train, svm_clf.predict(X_train))*100, 3), "%")
print("Accuracy of the testing set is ", round(accuracy_score(y_test, svm_clf.predict(X_test))*100, 3), "%")
print()
print("Done!!!!!!")